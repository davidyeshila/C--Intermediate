﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    [Serializable]
    class AccommodationList
    {
        //GenerateList of Accommodation
        public List<Accommodation> accommodation;

        //constructor to initiate the accommodation list
        public AccommodationList()
        {
            accommodation = new List<Accommodation>();
        }

        //adding accommodation to the list
        public bool AddAccommodation(Accommodation am)
        {
            bool success = true;

            foreach (Accommodation al in accommodation)
            {
                if (al.Rent_ID == am.Rent_ID)
                {
                    success = false;
                    return success;
                }
            }
            if (success)
            {
                accommodation.Add(am);
            }

            return success;
        }

        //removing accommodation from the accommodation list
        public bool RemoveAccommodation(Accommodation am)
        {
            bool msg=false;
            foreach (Accommodation al in accommodation)
            {
                if (al.Rent_ID == am.Rent_ID)
                {
                    accommodation.Remove(am);
                    msg = true;
                    return msg;
                }
            }
            
            return msg;
        }
    
        //returning an array of all the list
        public Accommodation[] returnlist()
        {
            if (accommodation.Count > 0)
            {
                Accommodation[] acm = new Accommodation[accommodation.Count];
                int c = 0;
                foreach (Accommodation al in accommodation)
                {
                    acm[c] = al;
                    c++;
                }
                return acm;
            }
            //if no items in the list then returns null
            return null;

        }
    }

}
