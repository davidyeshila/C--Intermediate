﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Register
    {
        //declaring instance variable
        private double totalRent;

        //constructor initialises the totalRent to 0
        public Register()
        {
            totalRent = 0;
        }

        public void RentItem(IRentable IRent, int iDays)
        {
            //increments the total rent with the rented item's fee
            totalRent = totalRent + (IRent.Rent_Fee*iDays);                        
        }

        //method shows the totalrent
        public string ShowTotal()
        {
            string msg;
            msg = "GRAND TOTAL: " + totalRent;
            //initialises the total rent back to 0;
            totalRent = 0;
            return msg;
        }
      
    }
}
