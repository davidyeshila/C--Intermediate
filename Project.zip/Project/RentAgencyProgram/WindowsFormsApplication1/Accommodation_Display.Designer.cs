﻿namespace WindowsFormsApplication1
{
    partial class Accommodation_Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstAccommodation = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboWeeks = new System.Windows.Forms.ComboBox();
            this.lblWeeks = new System.Windows.Forms.Label();
            this.btnRent = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstAccommodation
            // 
            this.lstAccommodation.FormattingEnabled = true;
            this.lstAccommodation.Location = new System.Drawing.Point(15, 59);
            this.lstAccommodation.Name = "lstAccommodation";
            this.lstAccommodation.Size = new System.Drawing.Size(463, 134);
            this.lstAccommodation.TabIndex = 0;
            this.lstAccommodation.SelectedIndexChanged += new System.EventHandler(this.lstAccommodation_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Accommodation List:";
            // 
            // cboWeeks
            // 
            this.cboWeeks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboWeeks.FormattingEnabled = true;
            this.cboWeeks.Location = new System.Drawing.Point(58, 206);
            this.cboWeeks.Name = "cboWeeks";
            this.cboWeeks.Size = new System.Drawing.Size(47, 21);
            this.cboWeeks.TabIndex = 11;
            this.cboWeeks.SelectedIndexChanged += new System.EventHandler(this.cboWeeks_SelectedIndexChanged);
            // 
            // lblWeeks
            // 
            this.lblWeeks.AutoSize = true;
            this.lblWeeks.Location = new System.Drawing.Point(12, 209);
            this.lblWeeks.Name = "lblWeeks";
            this.lblWeeks.Size = new System.Drawing.Size(44, 13);
            this.lblWeeks.TabIndex = 10;
            this.lblWeeks.Text = "Weeks:";
            // 
            // btnRent
            // 
            this.btnRent.Location = new System.Drawing.Point(131, 206);
            this.btnRent.Name = "btnRent";
            this.btnRent.Size = new System.Drawing.Size(99, 23);
            this.btnRent.TabIndex = 9;
            this.btnRent.Text = "Rent";
            this.btnRent.UseVisualStyleBackColor = true;
            this.btnRent.Click += new System.EventHandler(this.btnRent_Click_1);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(363, 206);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 49);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add Accommodation";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            // 
            // Accommodation_Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 260);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.cboWeeks);
            this.Controls.Add(this.lblWeeks);
            this.Controls.Add(this.btnRent);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstAccommodation);
            this.Name = "Accommodation_Display";
            this.Text = "Accommodations";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Accommodation_Display_FormClosed);
            this.Load += new System.EventHandler(this.Accommodation_Display_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstAccommodation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboWeeks;
        private System.Windows.Forms.Label lblWeeks;
        private System.Windows.Forms.Button btnRent;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBack;
    }
}