﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class EmptyFormException:Exception
    {
        //message to be displayed
        private static string msg = "There are missing values in the form.";

        //constructor passes the msg to the Exception class
        public EmptyFormException()
            : base(msg)
        {         
        }
    }
}
