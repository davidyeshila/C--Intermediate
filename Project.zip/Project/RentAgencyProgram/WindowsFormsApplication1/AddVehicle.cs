﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AddVehicle : Form
    {
        public AddVehicle()
        {
            InitializeComponent();
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            //finding the group control
            foreach (Control C in this.Controls)
            {
                if (C is GroupBox)
                {
                    string msg = "";
                    //looping through each textbox to check whether it is empty
                    foreach (Control T in C.Controls)
                    {
                        if (T.Text == "")
                        {
                            //if textbox is empty than adds the the texbox name to the string
                            msg += T.Name + Environment.NewLine;
                        }
                    }
                    //if textbox is empty then exits the method and displays the user to enter these values
                    if (msg != "")
                    { 
                        MessageBox.Show("Please fill in the following values"+Environment.NewLine+msg);
                        
                        return;
                    }
                }
                this.Add_Button.DialogResult = System.Windows.Forms.DialogResult.OK;
                    
                
            }
           
            
        }
        public Car GetData()
        {
            //trycatch block for checking the format
            try
            {
                string rentID = txtrentID.Text;
                double Engine = Convert.ToDouble(txtEngine.Text);
                int Speed = Convert.ToInt32(txtMaxSpeed.Text);
                string colour = txtColour.Text;
                string Make = txtMake.Text;
                double Fee = Convert.ToDouble(txtFee.Text);
                int Doors = Convert.ToInt32(txtDoors.Text);
                string type = txtType.Text;
                return new Car(rentID, Engine, Speed, colour, Make, Fee, Doors, type);
            }
            catch(FormatException)
            { 
                MessageBox.Show("Format was not correct, Vehicle was not added to the list");
                return null;
            }
        }

        private void AddVehicle_Load(object sender, EventArgs e)
        {

        }

        private void txtEngine_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtMaxSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtDoors_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }
        
    }
}
