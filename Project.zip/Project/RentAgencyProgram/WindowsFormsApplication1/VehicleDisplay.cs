﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace WindowsFormsApplication1
{
    public partial class VehiclesForm : Form
    {
        public VehiclesForm()
        {
            InitializeComponent();
        }

        //instatiate Vehicle List Object;
        VehicleList vehicle = new VehicleList();
        //Declaring the variables to be returned to the Register
        Vehicles rented;
        int iNum;

        private void Form1_Load(object sender, EventArgs e)
        {
            //Loading Data
            LoadData();

            //inserting the values for  cboDays
            Generate_Days();

            FillVehicleList();
        }

        //method to fill the vehicle list box
        public void FillVehicleList()
        {
            lstVehicles.Items.Clear();

            try
            {
                //array to hold all the vehicles
                Vehicles[] vehi = vehicle.returnlist();

                for (int c = 0; c < vehi.Count(); c++)
                {
                    lstVehicles.Items.Add(vehi[c]);
                }
                cboDays.Text = "";
            }
            catch (Exception)
            {
                MessageBox.Show("List is Empty");
            }
            
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            try
            {
                iNum = Convert.ToInt32(cboDays.Text);
                Vehicles v = (Vehicles)lstVehicles.SelectedItem;

                //putting the selected item to the rented svariable
                rented = v;
                vehicle.RemoveVehicle(v);

                FillVehicleList();
            }
            catch(Exception er)
            {
                MessageBox.Show(er.Message);
            }
            
        }

        //method to pass it to the home form to add to the register
        public Vehicles rentedItem()
        {
            return rented;
        }

        //returning the number of days to the register form
        public int Days()
        {
            return iNum;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                bool success;
                //code for retrieveing new Car object and adding it to the list
                AddVehicle addvehicle = new AddVehicle();
                if (addvehicle.ShowDialog() == DialogResult.OK)
                {
                    
                    Car vh = addvehicle.GetData(); //get new Vehicle information

                    if (vh != null)
                    {
                       

                        success=vehicle.AddVehicle(vh);

                        //checking if the same ID exists
                        if (success == true)
                        {
                            MessageBox.Show("Added to List");
                            FillVehicleList();
                        }
                        else
                        {
                            MessageBox.Show("Sorry but the Rent_ID has already been taken, please try again");
                        }
                    }
                }
            }
            catch(EmptyFormException ex)
            {
                MessageBox.Show(ex.Message);
            }   
        }

        //method to fill the combobox which shows the days
        public void Generate_Days()
        {            
            for (int c = 1; c <= 31; c++)
            {
                cboDays.Items.Add(c);
            }
        }

        //method to display the cboDays
        private void lstVehicles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstVehicles.SelectedIndex>=0)
            {
                lblDays.Visible = true;
                cboDays.Visible = true;
            }
        }

        //method to display the button Rent
        private void cboDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboDays.SelectedIndex >= 0)
            {
                btnRent.Visible = true;
            }
        }

        //method to save data
        public void SaveData()
        {
            FileStream outfile;
            BinaryFormatter bformatter = new BinaryFormatter();

            if(vehicle.vehicles.Count()>-1)
            {
                //creating an array to hold the vehicle objects
                Vehicles[] vArray = vehicle.returnlist();

                if (vArray != null)
                {
                    //open file for output
                    outfile = new FileStream("Vehicles.dat", FileMode.Create, FileAccess.Write);

                    //writing to the file
                    for (int i = 0; i < vArray.Count(); i++)
                    {
                        //save object using serialziation
                        bformatter.Serialize(outfile, vArray[i]);
                    }
                    //close the file
                    outfile.Close();
                }
            }
        }
        //method to load data using filestream and binary formatter
        public void LoadData()
        {
            FileStream infile;
            BinaryFormatter bformatter = new BinaryFormatter();
            Vehicles vh;

            if (File.Exists("Vehicles.dat"))
            { 
                //open file fore input
                infile = new FileStream("Vehicles.dat", FileMode.Open, FileAccess.Read);

                //loop until all objects has been read and add to the vehicle list
                while (infile.Position < infile.Length)
                {
                    vh = (Vehicles)bformatter.Deserialize(infile);
                    vehicle.AddVehicle(vh);

                }

                //close file
                infile.Close();

            }
        }

        private void VehiclesForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveData();
        }
            
        }        
}
