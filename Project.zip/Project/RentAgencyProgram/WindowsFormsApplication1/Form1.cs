﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class VehiclesForm : Form
    {
        public VehiclesForm()
        {
            InitializeComponent();
        }

        //instatiate Vehicle List Object;
        VehicleList vehicle = new VehicleList();
        //instatiate Accommodation List Objects
        AccommodatioList accommodations = new AccommodatioList();
        //instatiate register
        Register register = new Register();

        private void Form1_Load(object sender, EventArgs e)
        {
            Generate_Days();
            //instatiate Vehicle objects
            Car c1= new Car("1234",2,77,"red","bmw",200,2,"Sedan");
            Car c2= new Car("2345",3,90,"blue","mercedes",300,2,"Hatchback");

            vehicle.AddVehicle(c1);
            vehicle.AddVehicle(c2);


            FillVehicleList();

            /*    register.RentItem(c1);
            string msg=vehicle.RemoveVehicle(c2);
            MessageBox.Show(vehicle.Display());
            */
        }

        public void FillVehicleList()
        {
            lstVehicles.Items.Clear();
            //array to hold all the vehicles
            Vehicles[] vehi = vehicle.returnlist();

            for (int c = 0; c < vehi.Count(); c++)
            {
                lstVehicles.Items.Add(vehi[c]);
            }
            cboDays.Text = "";
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            int iNum;
            try
            {
            if (cboDays.Text == "")
            {
                MessageBox.Show("Please Type in number of Days.");
            }
            else
            {
                iNum = Convert.ToInt32(cboDays.Text);
                Vehicles v = (Vehicles)lstVehicles.SelectedItem;
                register.RentItem(v);
                MessageBox.Show(register.ShowTotal());
                vehicle.RemoveVehicle(v);

                FillVehicleList();
            }
            }
            catch
            {
                MessageBox.Show("Please type in only integer values");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            

            AddVehicle addvehicle = new AddVehicle();
            if (addvehicle.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Added to List");
                Car vh = addvehicle.GetData(); //get new Vehicle information

                vehicle.AddVehicle(vh);

                FillVehicleList();
            }
        }

        public void Generate_Days()
        {            
            for (int c = 1; c <= 31; c++)
            {
                cboDays.Items.Add(c);
            }
        }
    }
}
