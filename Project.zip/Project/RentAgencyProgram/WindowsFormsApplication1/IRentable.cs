﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    interface IRentable
    {
        //returning the Rent_fee of the selected object type
        double Rent_Fee { get; }

    }
}
