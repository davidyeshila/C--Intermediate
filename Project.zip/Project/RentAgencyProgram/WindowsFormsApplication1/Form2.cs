﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AddVehicle : Form
    {/*
        double dEngine;
        int iSpeed;
        double dFee;
        int iDoors; */

        public AddVehicle()
        {
            InitializeComponent();
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            /*
            try
            {
                dEngine = Convert.ToDouble(txtEngine.Text);
                iSpeed = Convert.ToInt32(txtMaxSpeed.Text);
                dFee = Convert.ToDouble(txtFee.Text);
                iDoors = Convert.ToInt32(txtDoors.Text);

                foreach (var textBox in grpVehicle.Controls.OfType<TextBox>())
                {
                    if (textBox.Text != null)
                    {

                    }
                    else
                    {
                        MessageBox.Show("Please add the values for each text box");
                    }
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Please enter the relevent Data types");
            }
             */
           
            
        }
        public Car GetData()
        {
            string rentID = txtrentID.Text;
            double Engine = Convert.ToDouble(txtEngine.Text);
            int Speed = Convert.ToInt32(txtMaxSpeed.Text);
            string colour = txtColour.Text;
            string Make = txtMake.Text;
            double Fee = Convert.ToDouble(txtFee.Text);
            int Doors = Convert.ToInt32(txtDoors.Text);
            string type = txtType.Text;
            return new Car(rentID, Engine, Speed, colour, Make, Fee, Doors, type);
        }

        private void AddVehicle_Load(object sender, EventArgs e)
        {

        }
        
    }
}
