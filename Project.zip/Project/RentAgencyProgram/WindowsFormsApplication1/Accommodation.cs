﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    [Serializable]
    public abstract class Accommodation:IRentable
    {
        //private instance variables
        private string rent_ID;
        private string address;
        private double rent_fee;
        private int rooms;
        private string owner_name;
        private string owner_contactno;

        public string Rent_ID
        {
            get { return rent_ID; }
        }
        
        //property
        public double Rent_Fee
        {
            get { return rent_fee; }
            set { rent_fee = value; }
        }
        public string Address
        {
            get { return address; }
        }
       
        //constructor
        public Accommodation(string sRentID, string sAddress, double dRent_fee, int iRooms, string sOwner, string scontact )
        {
            rent_ID = sRentID;
            address = sAddress;
            rent_fee = dRent_fee;
            rooms = iRooms;
            owner_name = sOwner;
            owner_contactno = scontact;
        }
    }
    [Serializable]
    public class Studio : Accommodation
    {
        //instance variable
        int floor;

        //constructor
        public Studio(string srent_id, string sAddress, double dRent, int iRooms, string sowner, string scontact, int ifloor)
        :base(srent_id,sAddress,dRent,iRooms,sowner,scontact)
        {
            floor = ifloor;        
        }

        //overriding ToString
        public override string ToString()
        {
            return "Studio: "+Rent_ID+"  Address:"+Address+"  fee:"+Rent_Fee+"  floor:"+floor;
        }
    }

    [Serializable]
    public class Bungalow : Accommodation
    {
        //constructor
        public Bungalow(string srent_id, string sAddress, double dRent, int iRooms, string sowner, string scontact)
            : base(srent_id, sAddress, dRent, iRooms, sowner, scontact)
        { 
        
        }

        //override string
        public override string ToString()
        {
            return "Bungalow:" + Rent_ID + "  Address:" + Address + "  Rent:" + Rent_Fee;
        }
    }
}
