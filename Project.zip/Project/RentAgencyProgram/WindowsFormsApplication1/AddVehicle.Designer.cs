﻿namespace WindowsFormsApplication1
{
    partial class AddVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDoors = new System.Windows.Forms.TextBox();
            this.txtMake = new System.Windows.Forms.TextBox();
            this.txtMaxSpeed = new System.Windows.Forms.TextBox();
            this.txtEngine = new System.Windows.Forms.TextBox();
            this.txtrentID = new System.Windows.Forms.TextBox();
            this.txtFee = new System.Windows.Forms.TextBox();
            this.txtColour = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Add_Button = new System.Windows.Forms.Button();
            this.grpVehicle = new System.Windows.Forms.GroupBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.grpVehicle.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtDoors
            // 
            this.txtDoors.Location = new System.Drawing.Point(106, 211);
            this.txtDoors.MaxLength = 1;
            this.txtDoors.Name = "txtDoors";
            this.txtDoors.Size = new System.Drawing.Size(100, 20);
            this.txtDoors.TabIndex = 0;
            this.txtDoors.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDoors_KeyPress);
            // 
            // txtMake
            // 
            this.txtMake.Location = new System.Drawing.Point(106, 151);
            this.txtMake.Name = "txtMake";
            this.txtMake.Size = new System.Drawing.Size(100, 20);
            this.txtMake.TabIndex = 1;
            // 
            // txtMaxSpeed
            // 
            this.txtMaxSpeed.Location = new System.Drawing.Point(106, 95);
            this.txtMaxSpeed.MaxLength = 3;
            this.txtMaxSpeed.Name = "txtMaxSpeed";
            this.txtMaxSpeed.Size = new System.Drawing.Size(100, 20);
            this.txtMaxSpeed.TabIndex = 2;
            this.txtMaxSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMaxSpeed_KeyPress);
            // 
            // txtEngine
            // 
            this.txtEngine.Location = new System.Drawing.Point(106, 65);
            this.txtEngine.MaxLength = 2;
            this.txtEngine.Name = "txtEngine";
            this.txtEngine.Size = new System.Drawing.Size(100, 20);
            this.txtEngine.TabIndex = 3;
            this.txtEngine.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEngine_KeyPress);
            // 
            // txtrentID
            // 
            this.txtrentID.Location = new System.Drawing.Point(106, 35);
            this.txtrentID.Name = "txtrentID";
            this.txtrentID.Size = new System.Drawing.Size(100, 20);
            this.txtrentID.TabIndex = 4;
            // 
            // txtFee
            // 
            this.txtFee.Location = new System.Drawing.Point(106, 181);
            this.txtFee.MaxLength = 4;
            this.txtFee.Name = "txtFee";
            this.txtFee.Size = new System.Drawing.Size(100, 20);
            this.txtFee.TabIndex = 5;
            this.txtFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFee_KeyPress);
            // 
            // txtColour
            // 
            this.txtColour.Location = new System.Drawing.Point(106, 121);
            this.txtColour.Name = "txtColour";
            this.txtColour.Size = new System.Drawing.Size(100, 20);
            this.txtColour.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Rent_ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Engine Size(litres):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Max Speed(miles):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Colour:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Make:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Rent Fee/Day:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "No. of Doors:";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(106, 237);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(100, 20);
            this.txtType.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(64, 240);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Type:";
            // 
            // Add_Button
            // 
            this.Add_Button.Location = new System.Drawing.Point(91, 315);
            this.Add_Button.Name = "Add_Button";
            this.Add_Button.Size = new System.Drawing.Size(75, 23);
            this.Add_Button.TabIndex = 18;
            this.Add_Button.Text = "Add Vehicle";
            this.Add_Button.UseVisualStyleBackColor = true;
            this.Add_Button.Click += new System.EventHandler(this.Add_Button_Click);
            // 
            // grpVehicle
            // 
            this.grpVehicle.Controls.Add(this.label1);
            this.grpVehicle.Controls.Add(this.txtDoors);
            this.grpVehicle.Controls.Add(this.txtMake);
            this.grpVehicle.Controls.Add(this.label9);
            this.grpVehicle.Controls.Add(this.txtMaxSpeed);
            this.grpVehicle.Controls.Add(this.txtType);
            this.grpVehicle.Controls.Add(this.txtEngine);
            this.grpVehicle.Controls.Add(this.label8);
            this.grpVehicle.Controls.Add(this.txtrentID);
            this.grpVehicle.Controls.Add(this.label7);
            this.grpVehicle.Controls.Add(this.txtFee);
            this.grpVehicle.Controls.Add(this.label6);
            this.grpVehicle.Controls.Add(this.txtColour);
            this.grpVehicle.Controls.Add(this.label5);
            this.grpVehicle.Controls.Add(this.label2);
            this.grpVehicle.Controls.Add(this.label3);
            this.grpVehicle.Location = new System.Drawing.Point(24, 41);
            this.grpVehicle.Name = "grpVehicle";
            this.grpVehicle.Size = new System.Drawing.Size(231, 268);
            this.grpVehicle.TabIndex = 20;
            this.grpVehicle.TabStop = false;
            this.grpVehicle.Text = "Add New Vehicle";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 18;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            // 
            // AddVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(283, 369);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.grpVehicle);
            this.Controls.Add(this.Add_Button);
            this.Name = "AddVehicle";
            this.Text = "Add Vehicle";
            this.Load += new System.EventHandler(this.AddVehicle_Load);
            this.grpVehicle.ResumeLayout(false);
            this.grpVehicle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtDoors;
        private System.Windows.Forms.TextBox txtMake;
        private System.Windows.Forms.TextBox txtMaxSpeed;
        private System.Windows.Forms.TextBox txtEngine;
        private System.Windows.Forms.TextBox txtrentID;
        private System.Windows.Forms.TextBox txtFee;
        private System.Windows.Forms.TextBox txtColour;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Add_Button;
        private System.Windows.Forms.GroupBox grpVehicle;
        private System.Windows.Forms.Button btnBack;
    }
}