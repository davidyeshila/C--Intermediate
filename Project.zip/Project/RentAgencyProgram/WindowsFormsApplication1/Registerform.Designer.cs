﻿namespace WindowsFormsApplication1
{
    partial class Registerform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAccommodation = new System.Windows.Forms.Button();
            this.btnVehicles = new System.Windows.Forms.Button();
            this.lstRegister = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnViewTotal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAccommodation
            // 
            this.btnAccommodation.Location = new System.Drawing.Point(276, 73);
            this.btnAccommodation.Name = "btnAccommodation";
            this.btnAccommodation.Size = new System.Drawing.Size(136, 46);
            this.btnAccommodation.TabIndex = 0;
            this.btnAccommodation.Text = "Accommodation";
            this.btnAccommodation.UseVisualStyleBackColor = true;
            this.btnAccommodation.Click += new System.EventHandler(this.btnAccommodation_Click);
            // 
            // btnVehicles
            // 
            this.btnVehicles.Location = new System.Drawing.Point(276, 122);
            this.btnVehicles.Name = "btnVehicles";
            this.btnVehicles.Size = new System.Drawing.Size(136, 46);
            this.btnVehicles.TabIndex = 1;
            this.btnVehicles.Text = "Vehicles";
            this.btnVehicles.UseVisualStyleBackColor = true;
            this.btnVehicles.Click += new System.EventHandler(this.btnVehicles_Click);
            // 
            // lstRegister
            // 
            this.lstRegister.FormattingEnabled = true;
            this.lstRegister.Location = new System.Drawing.Point(23, 73);
            this.lstRegister.Name = "lstRegister";
            this.lstRegister.Size = new System.Drawing.Size(209, 95);
            this.lstRegister.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Register:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Renting Agency";
            // 
            // btnViewTotal
            // 
            this.btnViewTotal.Location = new System.Drawing.Point(97, 182);
            this.btnViewTotal.Name = "btnViewTotal";
            this.btnViewTotal.Size = new System.Drawing.Size(135, 30);
            this.btnViewTotal.TabIndex = 5;
            this.btnViewTotal.Text = "View Total";
            this.btnViewTotal.UseVisualStyleBackColor = true;
            this.btnViewTotal.Click += new System.EventHandler(this.btnViewTotal_Click);
            // 
            // Registerform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 224);
            this.Controls.Add(this.btnViewTotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstRegister);
            this.Controls.Add(this.btnVehicles);
            this.Controls.Add(this.btnAccommodation);
            this.Name = "Registerform";
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAccommodation;
        private System.Windows.Forms.Button btnVehicles;
        private System.Windows.Forms.ListBox lstRegister;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnViewTotal;
    }
}