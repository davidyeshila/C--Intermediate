﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    [Serializable]
    class VehicleList
    {
        //GenericList of Vehicles
        public List<Vehicles> vehicles;

        //constructor to initiate the vehicle list
        public VehicleList()
        {
            vehicles = new List<Vehicles>();
        }

        //adding vehicles to the list
        public bool AddVehicle(Vehicles vh)
        {
            bool success = true;

            foreach (Vehicles vl in vehicles)
            {
                if (vl.Rent_ID == vh.Rent_ID)
                {
                    success = false;
                    return success;
                }
            }
            if (success)
            {
                vehicles.Add(vh);
            }

            return success;
        }

        //removing vehicles from the vehiclelist
        public bool RemoveVehicle(Vehicles vh)
        {
            bool msg = false; ;
            foreach (Vehicles vl in vehicles)
            {
                if (vl.Rent_ID == vh.Rent_ID)
                {
                    vehicles.Remove(vl);

                    msg = true;
                    return msg;
                }                               
            }
            return msg;

        }
        
        
        //returning an array of all the list
        public Vehicles[] returnlist()
        {
            if (vehicles.Count > 0)
            {
                Vehicles[] vehi = new Vehicles[vehicles.Count];
                int c = 0;
                foreach (Vehicles vl in vehicles)
                {
                    vehi[c] = vl;
                    c++;
                }
                return vehi;
            }

            //if no vehicle objects in the list then returns null
            return null;
        }
    }
}
