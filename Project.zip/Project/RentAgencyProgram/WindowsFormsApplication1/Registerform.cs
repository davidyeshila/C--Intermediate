﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Registerform : Form
    {
        public Registerform()
        {
            InitializeComponent();
        }

        //Declaring the register class to rent the items
        Register register = new Register();

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void btnVehicles_Click(object sender, EventArgs e)
        {
            //initialsing the form to be opened
            VehiclesForm vForm = new VehiclesForm();

            if (vForm.ShowDialog() == DialogResult.OK)
            {
                //receives data from the form
                int iDays = vForm.Days();
                Vehicles rented = vForm.rentedItem();

                //Adds the item to the lst Register
                lstRegister.Items.Add("Vehicle ID:" + rented.Rent_ID + " Fee:" + rented.Rent_Fee);

                //rents the vehicle item
                register.RentItem(rented, iDays);
            }
           
        }

        private void btnAccommodation_Click(object sender, EventArgs e)
        {
            //initialises the form to be opened
            Accommodation_Display accoForm = new Accommodation_Display();

            //if the forms dialog is ok then performs the following
            if (accoForm.ShowDialog() == DialogResult.OK)
            {
                //receives data to rent the item returned
                int iWeeks = accoForm.Weeks();
                Accommodation rented = accoForm.rentedItem();

                //Adding the Item to the Register
                lstRegister.Items.Add("Accommodation ID:"+rented.Rent_ID+" Fee:"+rented.Rent_Fee);
                //renting the item
                register.RentItem(rented, iWeeks);

            }
        }

        private void btnViewTotal_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            //displaying a message to give the user another chance to think about the decision
            dr = MessageBox.Show("Are you sure you want to close the register?", "Close Register?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            //if decision is OK the shows the user the Total
            // and clears the register list
            if (dr == DialogResult.OK)
            {
                MessageBox.Show(register.ShowTotal());
                lstRegister.Items.Clear();
            }
        }

        
    }
}
