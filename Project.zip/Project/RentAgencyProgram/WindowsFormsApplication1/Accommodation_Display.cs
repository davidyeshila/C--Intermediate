﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace WindowsFormsApplication1
{
    public partial class Accommodation_Display : Form
    {
        public Accommodation_Display()
        {
            InitializeComponent();
        }

        //instantiate accommodation List
        AccommodationList accommodations = new AccommodationList();
        //Declaring variables to be returned to the register
        int iNum;
        Accommodation rented;


        private void Accommodation_Display_Load(object sender, EventArgs e)
        {
            //generating the values for the combo box
            GenerateWeeks();
            //loading the list which has been saved
            LoadData();

            FillAccommodationList();
            visibility();           
        }

        public void visibility()
        {
            //making these items invisible to provide a 
            //structured manner and for validation purposes
            lstAccommodation.SelectedIndex = -1;
            lblWeeks.Visible = false;
            cboWeeks.Visible = false;
            btnRent.Visible = false;
        }

        //method to fill the accommodation list box
        public void FillAccommodationList()
        {
            lstAccommodation.Items.Clear();
            //trycatch block to validate the code
            try
            {
                //array to hold all the accommodation
                Accommodation[] acm = accommodations.returnlist();

                for (int c = 0; c < acm.Count(); c++)
                {
                    lstAccommodation.Items.Add(acm[c]);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("List is Empty");
            }

            cboWeeks.Text = "";
        }

        private void btnRent_Click_1(object sender, EventArgs e)
        {
                iNum = Convert.ToInt32(cboWeeks.Text);
                Accommodation acm = (Accommodation)lstAccommodation.SelectedItem;

                //putting the selected item to the rented variable
                rented = acm;
                accommodations.RemoveAccommodation(acm);

                //calling this function to refresh the list
                FillAccommodationList();
                btnRent.DialogResult = System.Windows.Forms.DialogResult.OK;

                //resetting the items visibility on the form
                visibility();
            
        }
        //method to pass the rented object to the register
        public Accommodation rentedItem()
        {
            return rented;
        }

        //returning the number of weeks to the register form
        public int Weeks()
        {
            return iNum;
        }

        //method to fill the week combo box
        public void GenerateWeeks()
        {
            for (int c = 1; c < 13; c++)
            {
                cboWeeks.Items.Add(c);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //code for retrieving new Accommodation from accomodation form and insert it to the list
            Add_Accommodation add_acco = new Add_Accommodation();

            //using the try catch block to make sure errors are taken care of
            try
            {
                bool success;
                //recieving accommodation object from the add accommodation form 
                //and adding to the list
                if (add_acco.ShowDialog() == DialogResult.OK)
                {
                    Accommodation acm = add_acco.GetData();
                    success=accommodations.AddAccommodation(acm);

                    //checking if the same ID exists
                    if (success == false)
                    {
                        MessageBox.Show("Sorry but the Rent_ID has already been taken, please try again");
                    }
                    else
                    {
                        FillAccommodationList();
                    }
                }
            }
            catch(EmptyFormException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //method to display the weeks items
        private void lstAccommodation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAccommodation.SelectedIndex >= 0)
            {
                lblWeeks.Visible = true;
                cboWeeks.Visible = true;
            }
        }

        //method to provide validation and display the rent button upon selection of weeks
        private void cboWeeks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboWeeks.SelectedIndex >= 0)
            {
                btnRent.Visible = true;
            }
        }

        private void SavedData()
        {
            //Declaring these keywords to allow data persistence
            FileStream outfile;
            BinaryFormatter bFormatter = new BinaryFormatter();
            
            //using the trycatch block to check if there is any accommodations in the list
            try
            {
                if (accommodations.accommodation.Count() > 0)
                {
                    //taking the objects into an array
                    Accommodation[] accoArrray = accommodations.returnlist();

                    //open file for output
                    outfile = new FileStream("Accommodation.dat", FileMode.Create, FileAccess.Write);

                    for (int i = 0; i < accoArrray.Count(); i++)
                    {
                        //output object to file via serialization
                        bFormatter.Serialize(outfile, accoArrray[i]);
                    }

                    //close the file
                    outfile.Close();
                }
            }
            catch 
            { }

        }

        //method to load data using FileStream and BinaryFormatter
        public void LoadData()
        {
            FileStream infile;
            BinaryFormatter bFormatter = new BinaryFormatter();
            Accommodation acm;

            if (File.Exists("Accommodation.dat"))
            { 
                //open file for input
                infile = new FileStream("Accommodation.dat", FileMode.Open, FileAccess.Read);

                //loop until all the objects has been read
                while (infile.Position < infile.Length)
                {
                    acm = (Accommodation)bFormatter.Deserialize(infile);
                    accommodations.AddAccommodation(acm);
                }

                //close the file
                infile.Close();
            }

        }

        private void Accommodation_Display_FormClosed(object sender, FormClosedEventArgs e)
        {
            //calling the savedata method when the form is closed
            SavedData();
        }
            
        }
    }