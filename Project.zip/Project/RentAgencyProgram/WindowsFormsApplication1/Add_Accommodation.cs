﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Add_Accommodation : Form
    {
        public Add_Accommodation()
        {
            InitializeComponent();
        }

        private void Add_Accommodation_Load(object sender, EventArgs e)
        {
            
        }

        private void cboType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //changing the visibility of the Studio's 'floor textbox'
            if (cboType.SelectedIndex == 0)
            {
                grpAccommodation.Text = "Studio";
                grpAccommodation.Visible = true;
                txtFloor.Visible = true;
                label8.Visible = true;
            }
            else
            {
                grpAccommodation.Text = "Bungalow";
                grpAccommodation.Visible = true;
                txtFloor.Visible = false;
                label8.Visible = false;
            }
        }

        private void txtFloor_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only numeric characters to enter
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtRooms_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //validating to check what type of accommodation it is
            if (cboType.SelectedIndex == 0)
            {
                //getting the controls in this form
                foreach (Control C in this.Controls)
                {
                    //to check the controls in the group box
                    if (C is GroupBox)
                    {
                        //msg string is created to output the user if any field has been left empty
                        String msg = "";
                        foreach (Control T in C.Controls)
                        {
                            //if a field is empty then adds to the msg string
                            if (T.Text == "")
                            {
                                msg += T.Name + Environment.NewLine;
                            }
                        }
                        //if msg is not null then displays the user the list of empty fields
                        if (msg != "")
                        {
                            MessageBox.Show("Please fill in the values for the following: " + msg);
                            return;
                        }
                    }
                }
            }
            else if (cboType.SelectedIndex == 1)
            {
                //Searching the controls
                foreach (Control C in this.Controls)
                {
                    //looping through the controls in the Groupbox
                    if (C is GroupBox)
                    {
                        String msg = "";
                        foreach (Control T in C.Controls)
                        {
                            if (T.Text == "")
                            {
                                //code to not display txtfloor since bungalow is rented as a whole
                                if (T.Name != "txtFloor")
                                {
                                    msg += T.Name + Environment.NewLine;
                                }                                
                            }
                        }
                        //if textbox is empty then exits the method and displays the user to enter these values
                        if (msg != "")
                        {
                            MessageBox.Show("Please fill in the values for the following: " + Environment.NewLine + msg);
                            return;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select type of accommodation");
            }

            //if there was no error found in entering the data into the fields then
            //the buttons dialogresult has been set to OK
            this.btnAdd.DialogResult= System.Windows.Forms.DialogResult.OK;
        }

        public Accommodation GetData()
        {
            //tryblock to catch if format is invalid
            try
            {
                string rentid = txtRentID.Text;
                string address = txtAddress.Text;
                double Fee = Convert.ToDouble(txtFee.Text);
                int rooms = Convert.ToInt32(txtRooms.Text);
                string name = txtOwner.Text;
                string contact = txtContact.Text;


                if (cboType.SelectedIndex == 0)
                {
                    int floors = Convert.ToInt32(txtFloor.Text);
                    return new Studio(rentid, address, Fee, rooms, name, contact, floors);
                }
                else
                {                    
                    return new Bungalow(rentid, address, Fee, rooms, name, contact);
                }
            }            
            catch (FormatException)
            {
                MessageBox.Show("please review and enter the correct format");
                return null;
            }
        }

        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            //code to allow only digits
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        
    }
}
