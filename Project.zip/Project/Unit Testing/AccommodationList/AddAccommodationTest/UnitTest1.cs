﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

//add reference
using AccommodationList;

//using alias
using TestedClass = AccommodationList.AccommodationList;

namespace AccommodationListMethods
{
    [TestClass]
    public class TestFixture_AccommodationListMethods
    {
        //declare reference to the class being Tested
        private TestedClass AccoList;

        [TestInitialize]
        public void TestInitialize()
        { 
            // A new instance of the class is created for every test case.
            // This is therefore part of each test cases "Arrange" section.
            AccoList = new TestedClass();
        
        }

        [TestCleanup]
        public void TestCleanup()
        { 
            // Ensure that the object reference is set to null so any actual instance
            // can be garbage collected
            AccoList = null;
        }

        [TestMethod]
        public void AddAccommodation_TestStudioObject_TrueReturned()
        {
            //Arrange
            Studio obj1 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            bool expected = true;
            bool actual;

            // Act
            actual = AccoList.AddAccommodation(obj1);

            //Assert
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void AddAccommodation_TestStudioObject_FalseReturned()
        {
            //Arrange
            Studio obj1 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            Studio obj2 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            AccoList.AddAccommodation(obj1);

            bool expected = false;
            bool actual;

            // Act
            actual = AccoList.AddAccommodation(obj2);

            //Assert
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void RemoveAccommodation_removeStudioObject_TrueReturned()
        {
            //Arrange
            Studio obj1 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            bool expected = true;
            bool actual;

            // Act
            AccoList.AddAccommodation(obj1);
            actual = AccoList.RemoveAccommodation(obj1);

            //Assert
            Assert.AreEqual(expected, actual);        
        }

        [TestMethod]
        public void RemoveAccommodation_removeStudioObject_FalseReturned()
        {
            //Arrange
            Studio obj1 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            Studio obj2 = new Studio("234", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);

            bool expected = false;
            bool actual;

            // Act
            AccoList.AddAccommodation(obj1);
            actual = AccoList.RemoveAccommodation(obj2);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void returnList_returnAllAccommodation_ArrayReturned()
        { 
            //Arrange
            Studio obj1 = new Studio("124", "Clanny House, SR4 6US", 23.5, 1, "University", "0974043218", 2);
            Bungalow obj2 = new Bungalow("234", "Precinct,chester road", 67, 1, "University", "0091232424");
            AccoList.AddAccommodation(obj1);
            AccoList.AddAccommodation(obj2);

            Accommodation[] expected = new Accommodation[2];
            expected[0] = obj1;
            expected[1] = obj2;

            Accommodation[] actual;

            //Act
            actual = AccoList.returnlist();

            //Assert
            Assert.AreEqual(expected[0], actual[0]);
            Assert.AreEqual(expected[1], actual[1]);

        }

    }
}
