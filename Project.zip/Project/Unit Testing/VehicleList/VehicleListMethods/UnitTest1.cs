﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

// add reference
using VehicleList;

//using alias
using TestedClass = VehicleList.VehicleList;


namespace VehicleListMethods
{
    [TestClass]
    public class TestFixtureVehicleListMethods
    {
        // declare reference to the class being tested
        private TestedClass VehiList;

        [TestInitialize]
        public void TestInitialize()
        { 
            //a new instance of the class is created every test case
            //this is therefore part of each test case's arrange
            VehiList = new TestedClass();
        }

        [TestCleanup]
        public void TestCleanUp()
        { 
            //ensure that the object reference is set to null so any actual instance can be garbage collected
            VehiList = null;
        }

        [TestMethod]
        public void AddVehicle_TestCarObject_TrueReturned()
        {
            //Arrange
            bool expected = true;
            bool actual;
            Car c1 = new Car("12", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");

            //Act
            actual = VehiList.AddVehicle(c1);

            //assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AddVehicle_TestCarObject_FalseReturned()
        {
            //Arrange
            bool expected = false;
            bool actual;
            Car c1 = new Car("12", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");
            VehiList.AddVehicle(c1);

            Car c2 = new Car("12", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");

            //Act
            actual = VehiList.AddVehicle(c2);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void RemoveVehicle_TestCarObject_TrueReturned()
        {
            //Arrange
            bool expected = true;
            bool actual;
            Car c1 = new Car("12", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");
            VehiList.AddVehicle(c1);

            //Act
            actual = VehiList.RemoveVehicle(c1);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void RemoveVehicle_TestCarObject_FalseReturned()
        {
            //Arrange
            bool expected = false;
            bool actual;
            Car c1 = new Car("12", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");
            Car c2 = new Car("123", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");

            VehiList.AddVehicle(c1);

            //Act
            actual = VehiList.RemoveVehicle(c2);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void returnlist_returnAllVehicles_ArrayReturned()
        { 
            //Arrange
          
            Car c1 = new Car("12", 4, 3, "red", "mercedes", 80, 4, "sedan");
            Car c2 = new Car("123", 2.3, 2, "red", "bmw", 45.5, 2, "hatchback");
            VehiList.AddVehicle(c1);
            VehiList.AddVehicle(c2);

            Vehicles[] expected = new Vehicles[2];
            expected[0] = c1;
            expected[1] = c2;

            Vehicles[] actual;
            
            //Act
            actual = VehiList.returnlist();

            //Assert
            Assert.AreEqual(expected[0], actual[0]);
            Assert.AreEqual(expected[1], actual[1]);

        }

    }
}
