﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleList
{
    public class Vehicles
    {
        //private instace variables
        private string rent_ID;
        private double engine_size;
        private int speed;
        private string colour;
        private string make;
        private double rent_fee;

        //Property
        public double Rent_Fee
        {
            get { return rent_fee; }
            set { rent_fee = value; }
        }
        public string Rent_ID
        {
            get { return rent_ID; }
        }
        public string Make
        {
            get { return make; }
        }
        

        //Constructor
        public Vehicles(string sID, double dESize, int iSpeed, string sColour, string sMake, double dRent)
        {
            rent_ID = sID;
            engine_size = dESize;
            speed = iSpeed;
            colour = sColour;
            make = sMake;
            Rent_Fee = dRent;
        }

        
    }
    [Serializable]
    public class Car : Vehicles
    {
        //private instance variable
        private int doors;
        private string car_type;

        //constructor
        public Car(string sRent_id, double dengine, int ispeed, string scolour, string smake, double drent, int idoors, string stype)
            :base(sRent_id,dengine,ispeed,scolour,smake,drent)
        {
            doors = idoors;
            car_type = stype;
        }
        //overriding ToString
        public override string ToString()
        {
            return String.Format("{0,-15}{1,-15}{2,-10}",Rent_ID, Make, car_type);
        }
    }
}
    
